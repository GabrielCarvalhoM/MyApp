# Vilumo Fit — Canonical Index

<!-- EXP_CLOSURE_METADATA_START: EXP-CLOSE-r1 -->
**Chief closure — 2026-10-22: authority classification published, EXP-PUBLISH-20261022-001.** The EXP-AUTH-r1 material filter below passed independent fidelity/interpretability review and Chief consolidation; [final disposition](../audits/experience-decontamination-2026-10-22/FINAL_DISPOSITION.md). This EXP-CLOSE-r1 metadata does not change its scope or designate final Experience Truth. Original author-submission wording remains provenance.
<!-- EXP_CLOSURE_METADATA_END: EXP-CLOSE-r1 -->

<!-- EXPERIENCE_AUTHORITY_OVERLAY_START: EXP-AUTH-r1 -->
## Current authority filter — CI-3.3.0 / EXP-AUTH-r1 · 2026-10-22

Founder decision: [current direct request](../audits/experience-decontamination-2026-10-22/FOUNDER_REQUEST.md), **DECIDED / CURRENT_PRODUCT_DECISION**, formalized in [PDR DR-93–97](../product/PRODUCT_DECISION_REGISTER.md). The request supersedes only old experience authority; thesis identity, product capabilities, scientific uncertainty and domain/control/privacy/business constraints are preserved. PCG author submission: **GOVERNANCE_READY_FOR_REVIEW**; review/consolidation and exact revisions live in [this audit](../audits/experience-decontamination-2026-10-22/). A current direct Founder instruction applies without pretending the formalization already passed independent gates.

**Read for the independent new design:** [CURRENT_MISSION](../CURRENT_MISSION.md) → this authority filter → [DESIGNER_PRODUCT_CONTEXT](../product/DESIGNER_PRODUCT_CONTEXT.md). The brief is a subordinate derived view, not a second contract. Its narrow domain references are optional deepening; mixed experience documents and historical reports are not required designer onboarding. Do not follow historical reading sequences below automatically.

**PRODUCT / DOMAIN TRUTH** = what Vilumo is, knows, calculates, decides, permits and must constrain. **EXPERIENCE TRUTH** = how people access, understand and operate those capabilities. Current Founder direction → selected product/domain truth and valid behavioral/privacy/business constraints → candidate experience exploration. File rank never revives a retired visual or structural prescription.

### A / B / C responsibility map

| Source / retained revision | A — active product/domain truth | B — independent behavioral principles | C — legacy experience, no active authority |
|---|---|---|---|
| [Thesis PTC-3.2.1](VILUMO_FIT_PRODUCT_THESIS_CONTRACT.md) | Identity, scope, invariants, capabilities, evidence, privacy and business decisions remain. | C028–30/C033–36 relevance, direct operation, consistency, discoverability and stable task references; C048 quality/anti-bloat; C051 progressive depth. | Aesthetic reference paragraph; C048 dark-first/style prescriptions; C051 fixed levels/destination taxonomy; any inferred screen/composition. C056 old execution sequence is superseded by the current mission. No invariant is retired. |
| [Truth Map PTM-1.2](../product/PRODUCT_TRUTH_MAP.md) / [PDR-1.3](../product/PRODUCT_DECISION_REGISTER.md) + current overlays | Provenance/supersession and G01–G11 remain the single decision-gap inventory. DR-91 route/photo privacy and DR-92 semantic continuity remain. | Agency/history/inspect-versus-execute/confirmation and meaningful disclosure. | Prior visual authority references, DR-61 aesthetic use, DR-77 styling, DR-80 fixed three-level IA, DR-85 surface placement and DR-92 placement/tab restrictions; prior mission routing is historical. |
| [Scope RS-1.3](../product/V1_RELEASE_SCOPE.md) | IN/OUT, anti-bloat, first value, subscription, primary mobile/iPhone/iOS; Android adaptation remains. | Progressive depth and value before hard ask, useful execution and continuity. | Fixed destination names, placements, three-level taxonomy, old styling and visual handoff plan. Platform truth does not mandate old frames or navigation. |
| [PDM-1.3](../product/PRODUCT_DOMAIN_MODEL.md) / [AEC-1.3](../product/ADAPTIVE_ENGINE_CONTRACT.md) | Objects, ownership, state, authority, control, provenance, safety, privacy, wearable and entitlement semantics. | Inspect/read ≠ execute/apply; model update ≠ mutation; planned/chosen/executing/observed distinct; correct and revisit history. | Any inherited surface/placement language or reference to old experience documents is an implementation example, not required architecture. PDM's general location exclusion is qualified by DR-91; other sensitive data exclusions stand. |
| [AEOS-1.2-r2](../product/ADAPTIVE_ENGINE_OPERATIONAL_SPEC.md) / [AESL-1.2-r2](../product/ADAPTIVE_ENGINE_SCENARIO_LAB.md) | Decision process, policies/slots, B0/HC/JEV SHADOW, anti-loops, learning, agency and scenario oracles remain intact. | Honest explanation/confidence, scoped holds and traceable history. | UI projection examples or obsolete task progression cannot prescribe new surfaces. Oracles are specified, not evidence of execution. |
| [SIS-1.1-r2](../product/SPORT_INTELLIGENCE_SPEC.md) / [RIL-1.1-r1](../product/RUN_INTELLIGENCE_SPEC.md) / [STIL-1.1-r1](../product/STRENGTH_INTELLIGENCE_SPEC.md) | Full specialist depth, progression/programming/performance, Recovery/Load/Interference, evidence limits and approval triggers. | Domain-native semantics, uncertainty, comparison and measured/estimated distinction. | Old “existing objects/no new destinations” presentation instructions cannot freeze candidate architecture. This grants no new capability or scope. |
| [PA-1.3](../product/PRODUCT_ARCHITECTURE.md) | Data/authority boundaries, canonical references, consent, exposure allowlist, DR-91 route/photo security and entitlement remain binding. | Stable references, honest states, agency, direct operation and discoverability. | Destination inventory, hierarchy, entry/Today/Week/Progress composition, navigation, surface allocation and alternative decisions selecting old IA. |
| [EM-1.2](../product/EXPERIENCE_MODEL.md) / [CF-1.2](../product/CORE_FLOWS.md) | Preconditions, ownership, business/permission states, meaningful outcomes and recovery semantics remain. | Optional sharing, agency, continuity, progressive depth, value first and factual learning. | Old journeys as prescribed screen sequence, destinations, fixed levels, presentation and read order. Semantic state ordering such as authorization before effect still applies. |
| [UXS-1.1-FREEZE-r2 + V1C-r1](../product/UX_SPECIFICATION.md) | Only independently grounded domain/control/business/privacy semantics remain, including recent data inputs, rescheduling confirmation, historical facts and route/photo limits. | PR-02–12/14/16 semantic content; PR-01 relevance, PR-13 anti-bloat/quality, PR-15 progressive disclosure; SES inspect≠execute; evidence-aware copy including VIS-14's epistemic principle. | Experience architecture, alternatives, surface inventory, navigation, Today/Week/Progress and other compositions, fixed journey/step order, labels, cards, styles, candidates, frame/page instructions, visual tokens/encodings and VIS-03/05/10–20 visual locks. V1C build list is historical prescription. |

The split is at **clause/responsibility level**, not whole-file deprecation. A sentence combining a preserved constraint with a retired placement retains its constraint only. Examples: before a material plan mutation, show the actual scope and obtain valid agency; how that is accomplished belongs to the candidate. Inspecting a planned session must not start it; no old detail screen is mandatory. Distinguish a forecast from a measurement; no inherited line style, card or chart is mandatory. Domain safety, accessibility and privacy controls are not waived by retiring their old manifestations. An unresolved genuine semantic conflict returns to the relevant owner; old experience resemblance is never its resolution criterion.

### Design status and migration guardrails

| Design | Current classification | Authority |
|---|---|---|
| Prior file `NeaZKGCzHMy6IHc47cVEHs` | **LEGACY / SUPERSEDED AS ACTIVE UX AUTHORITY** | Historical evidence only. Prior approvals, locks and design-system/page/frame instructions do not bind the candidate. |
| Independent new Figma, identity/link not supplied | **NEW EXPERIENCE CANDIDATE / ACTIVE DESIGN EXPLORATION** | Owns candidate experience architecture under Product Truth; no inferred match to the old file. |
| Final Experience/Design Source of Truth | **NOT YET DESIGNATED** | Requires future intellectual reconciliation, evidence/claims audit and explicit promotion. No automatic final status or Figma-edit authority in this mission. |

THE NEW FIGMA OWNS THE EXPERIENCE ARCHITECTURE.
DOMAIN DOCUMENTS PROVIDE CAPABILITIES, CONSTRAINTS AND TRUTH — NOT LAYOUT.

PRODUCT CAPABILITY DOES NOT IMPLY UI SURFACE.

DO NOT ADD A SURFACE SOLELY BECAUSE A CAPABILITY EXISTS.

NO PIXEL MIGRATION. SEMANTIC MIGRATION ONLY.

DO NOT BEND THE NEW EXPERIENCE TO MATCH THE OLD FIGMA. BEND IT ONLY WHEN REQUIRED BY PRODUCT TRUTH.

### History, evidence and remaining gaps

The freeze was integrated in `32b7fb6`, with 16/16 source hashes verified at integration ([record](../audits/v1-freeze-sync-2026-10-19/INTEGRATION_RECORD.md)). “Isolated/pending sync” metadata below and in source headers describes its preparation history, not current integration state. Integration does not transfer old PASS to today's hashes. Product/domain bodies and all preexisting uncommitted product deltas are retained in place; overridden mission bytes are [snapshotted](../governance/snapshots/2026-10-22-pre-experience-decontamination/CURRENT_MISSION.md), ledger append-only.

Preserve provisional Founder commercial values (annual R$ 199,90; monthly R$ 59,90, recorded 2026-10-20) as provisional, not a frozen offer or evidence of demand; trial length/legal text remain open under G10/G07. DR-91 supersedes prior blanket route exclusions only for its explicitly chosen, bounded route purpose/artefact. These remain domain/business/privacy truth independently of old screen placement. Candidate identity is a future inventory gap owned by the design owner; missing identity does not grant permission to inspect another file. G01–G11 and claim limitations remain open as specified; documenting them proves neither implementation nor physiology nor release readiness.

### Prior index record — historical, filtered by the current overlay

The original CI-3.2.1-freeze text below is retained for provenance. Its authority selection, routing, reading order and pending-sync descriptions are superseded where they conflict with this current filter.
<!-- EXPERIENCE_AUTHORITY_OVERLAY_END: EXP-AUTH-r1 -->

Revisão **CI-3.2.1-freeze** · 2026-10-19 · **CANDIDATE_IN_ISOLATION**.
Este índice seleciona a V1 congelada para Visual/UI **na cópia isolada**. A integração/publicação deste patch e aceite do Claude ainda não ocorreram; não transferir PASS históricos a novos hashes. [Pedido Founder](../audits/v1-freeze-2026-10-19/FOUNDER_REQUEST.txt), [registro/auditoria A–Y](../audits/v1-freeze-2026-10-19/MISSION_RECORD.md), [handoff curto](../audits/v1-freeze-2026-10-19/CLAUDE_HANDOFF.md).

## Uma autoridade por responsabilidade

| Fonte | Revisão selecionada | Responsabilidade |
|---|---|---|
| [Thesis](VILUMO_FIT_PRODUCT_THESIS_CONTRACT.md) | PTC-3.2.1 | Identidade/invariantes/direção Founder; C047–61/L024 freeze + training doctrine. |
| [Truth Map](../product/PRODUCT_TRUTH_MAP.md) | PTM-1.2 | Rastreabilidade/supersessão, não segunda tese. |
| [Decision Register](../product/PRODUCT_DECISION_REGISTER.md) | PDR-1.3 | DR76–90 e único inventário G01–G11; bloco PDR-0.6 histórico. |
| [V1 Release Scope](../product/V1_RELEASE_SCOPE.md) | RS-1.3 | Seleção V1/roadmap deferred e critérios de profundidade, sem novos docs de scope. |
| [Domain](../product/PRODUCT_DOMAIN_MODEL.md) | PDM-1.3 | Objetos/ownership/estados e fronteiras. |
| [Adaptive Contract](../product/ADAPTIVE_ENGINE_CONTRACT.md) | AEC-1.3 | Autoridade comportamental/controle e estabilidade. |
| [AEOS](../product/ADAPTIVE_ENGINE_OPERATIONAL_SPEC.md) / [Lab](../product/ADAPTIVE_ENGINE_SCENARIO_LAB.md) | AEOS-1.2-r2 / AESL-1.2-r2 | Necessity/adequacy/change-cost/priority + B0/HC/JEV/guardas e oráculos futuros. |
| [Specialists](../product/SPORT_INTELLIGENCE_SPEC.md), [Run](../product/RUN_INTELLIGENCE_SPEC.md), [Strength](../product/STRENGTH_INTELLIGENCE_SPEC.md) | SIS-1.1-r2 / RIL-1.1-r1 / STIL-1.1-r1 | Fronteiras especialistas e núcleos decisórios, sem outro plano/policy. |
| [Architecture](../product/PRODUCT_ARCHITECTURE.md) | PA-1.3 | Destinos/caminhos/share allowlist/entitlement, sem composição visual. |
| [Experience](../product/EXPERIENCE_MODEL.md) / [Flows](../product/CORE_FLOWS.md) | EM-1.2 / CF-1.2 | Primeiro valor/semana/agência/estados/jornadas. |
| [Detailed UX](../product/UX_SPECIFICATION.md) | UXS-1.1-FREEZE-r2 | Sync da UX r3 para scope congelado; controles preservados, social deferred. |
| [Current Mission](../CURRENT_MISSION.md) / [Ledger](../MISSION_LEDGER.md) | MISSION-UXSPEC-1.0 / intactos | Gate original do Claude concluído durante o freeze, r3 sem mudança; SOURCE_PROGRESS.json registra fechamento. Patch não substitui missão/ledger ou reabre gate. |

Autoridade: pedido explícito Founder atual → tese → scope/AEC/domínio → estrutura/experiência/UX. O pacote mantém um produto, plano e Athlete Model. Nenhuma existência de arquivo, report ou referência a concorrente prova eficácia/mercado/qualidade real.

## Freeze e escopo atual

Run + Strength wedge premium. Crew inteira DEFERRED, NOT REJECTED, depois da validação; feed público/follower graph continuam proibidos pelos invariantes. External share próprio permanece V1 sem social network. Nutrition módulo completo deferred/apoio leve só quando elegível. Ingest-first; outbound condicional sem gate global de launch. Subscription-first/value-before-hard-ask. GoalHierarchy/primeira semana/progressive depth/deep analytics e stable-by-default/minimum effective change estão definidos. Sem novos módulos pelo escopo retirado.

22 invariantes anteriores preservados; L024 é o único novo, pedido diretamente. Specialist Parity target C045/C046 e núcleos RIL/STIL preservados com adendo C057–61; dedupe/carga/antiloops, HC/safety/agency/guarda/JEV SHADOW/LLM sem soberania mantidos. B0 recebe guard de necessidade para não trocar plano adequado só por melhora teórica.

## História e limites da aprovação

Inputs originais: snapshot Git 0bc196210686b72c4c72090d260bfe86289a6bc4 do MyApp, sem commits na origem. SIL revisado: 07a119b26f2008a9eaa2820d0300b98046952afe, preservado e consumido, não refeito. [Consolidação SIL](../audits/specialist-layers-2026-10-19/CONSOLIDATION.md). Publicações anteriores [rebaseline3.0](../audits/rebaseline-3.0.0/PUBLICATION_EVENT.json), [PREUX](../audits/pre-ux-2026-10-15/PUBLICATION_EVENT.json), [AEOS](../audits/adaptive-engine-2026-10-15/PUBLICATION_EVENT.json) e missão/reviews UXSPEC ficam intactos e válidos para seus hashes.

Audits/evidence são apoio, não Product Truth. Valores/leis/providers de packs antigos não são revalidados neste freeze e não devem ser citados como fatos atuais sem checagem na ativação. G01–G11 continuam antes de prescrição/coleta/claims/release dependentes; detalhes numéricos/técnicos/comerciais não impedem exploração visual honesta da arquitetura. Nenhum cenário/harness/device/treino foi executado por documentar oráculos; nenhum aceite do Claude ou gatilho visual já cumprido é presumido.

## Próximo passo

Gate do Claude concluído observado (SOURCE_PROGRESS.json); sincronizar patch combinado (contém SIL se ainda ausente), comparar apenas conflitos materiais surgidos depois da captura, checks mínimos e **diretamente Visual/UI premium**. Pedido Founder C056 autoriza essa sequência; sem repetir decisões de produto ou criar missão documental/research/large judge cycle. Esta missão não cria telas ou código nem mexe no gate corrente. Estado final por hashes e consolidação em [registro freeze](../audits/v1-freeze-2026-10-19/MISSION_RECORD.md).
